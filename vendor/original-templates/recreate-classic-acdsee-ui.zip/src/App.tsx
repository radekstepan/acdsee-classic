import { ReactNode, useCallback, useEffect, useRef, useState } from "react";
import { FOLDER, PHOTOS } from "./data/photos";
import { MenuBar, MenuDef, StatusBar, TBtn, Toolbar, TitleBar, TSep } from "./components/Chrome";
import { Filmstrip, SideList, SideThumbs, Well } from "./components/Panels";
import {
  AboutDlg,
  Message,
  MsgButtons,
  OpenDlg,
  OptionsDlg,
  ResizeDlg,
  RunDlg,
  TweakDlg,
  TweakState,
} from "./components/Dialogs";
import { StartItem, Taskbar } from "./components/Taskbar";
import {
  IcBin,
  IcCopy,
  IcFilm,
  IcFit,
  IcActual,
  IcFlipH,
  IcFlipV,
  IcFull,
  IcList,
  IcLogo16,
  IcMyComputer,
  IcOpen,
  IcPlay,
  IcPrint,
  IcRotL,
  IcRotR,
  IcSave,
  IcSplit,
  IcStop,
  IcThumb,
  IcTweak,
  IcZoomIn,
  IcZoomOut,
} from "./components/icons";

type Mode = "thumbnails" | "filmstrip" | "list" | "split";
type Zoom = { m: "fit" } | { m: "pct"; p: number };
type Dlg =
  | null
  | {
      k: "msg";
      title: string;
      text: string;
      icon?: "info" | "warn" | "excl";
      buttons?: MsgButtons[];
    }
  | { k: "about" }
  | { k: "open" }
  | { k: "tweak" }
  | { k: "resize" }
  | { k: "options" }
  | { k: "run" };

const STEPS = [25, 50, 75, 100, 150, 200, 300];
const N = PHOTOS.length;

function DIcon({
  label,
  icon,
  sel,
  onClick,
  onDbl,
}: {
  label: string;
  icon: ReactNode;
  sel: boolean;
  onClick: () => void;
  onDbl: () => void;
}) {
  return (
    <div
      className="flex w-[80px] flex-col items-center gap-[3px] p-1"
      onClick={(e) => {
        e.stopPropagation();
        onClick();
      }}
      onDoubleClick={onDbl}
    >
      {icon}
      <span
        className={
          "px-[3px] py-[1px] text-center text-[11px] leading-[13px] text-white " +
          (sel ? "bg-[#000080] outline-1 outline-dotted outline-white/70" : "")
        }
      >
        {label}
      </span>
    </div>
  );
}

export default function App() {
  const [idx, setIdx] = useState(0);
  const [mode, setMode] = useState<Mode>("thumbnails");
  const [zoom, setZoom] = useState<Zoom>({ m: "fit" });
  const [nat, setNat] = useState<Record<string, { w: number; h: number }>>({});
  const [rot, setRot] = useState(0);
  const [fH, setFH] = useState(false);
  const [fV, setFV] = useState(false);
  const [fw, setFw] = useState(false);
  const [play, setPlay] = useState(false);
  const [dur, setDur] = useState(3);
  const [loop, setLoop] = useState(true);
  const [filters, setFilters] = useState<TweakState>({ b: 100, c: 100, s: 100, h: 0 });
  const [dlg, setDlg] = useState<Dlg>(null);
  const [maxi, setMaxi] = useState(true);
  const [vis, setVis] = useState(true);
  const [shutdown, setShutdown] = useState(false);
  const [selIcon, setSelIcon] = useState<string | null>(null);

  const photo = PHOTOS[idx];
  const zoomScale = zoom.m === "fit" ? 1 : zoom.p / 100;
  const filter = `brightness(${filters.b}%) contrast(${filters.c}%) saturate(${filters.s}%) hue-rotate(${filters.h}deg)`;
  const rotXform = `rotate(${rot}deg)${fH ? " scaleX(-1)" : ""}${fV ? " scaleY(-1)" : ""}`;

  const nav = useCallback(
    (d: number) => {
      setPlay(false);
      setIdx((i) => (i + d + N) % N);
    },
    []
  );

  const zIn = () =>
    setZoom((z) => {
      if (z.m === "fit") return { m: "pct", p: 100 };
      const next = STEPS.find((s) => s > z.p);
      return next ? { m: "pct", p: next } : z;
    });
  const zOut = () =>
    setZoom((z) => {
      if (z.m === "fit") return z;
      const prev = [...STEPS].reverse().find((s) => s < z.p);
      return prev ? { m: "pct", p: prev } : { m: "fit" };
    });

  const onNat = useCallback((id: string, n: { w: number; h: number }) => {
    setNat((m) => (m[id] ? m : { ...m, [id]: n }));
  }, []);

  /* slideshow auto-advance */
  const idxRef = useRef(idx);
  idxRef.current = idx;
  useEffect(() => {
    if (!play) return;
    const t = setInterval(() => {
      const next = (idxRef.current + 1) % N;
      if (!loop && next === 0) {
        setPlay(false);
        return;
      }
      setIdx(next);
    }, dur * 1000);
    return () => clearInterval(t);
  }, [play, dur, loop]);

  const msg = (title: string, text: string, icon: "info" | "warn" | "excl" = "info") =>
    setDlg({ k: "msg", title, text, icon });

  /* actions */
  const open = () => setDlg({ k: "open" });
  const save = () => msg("Save", `C:\\PICTURES\\${photo.name} saved.`);
  const saveAs = () => msg("Save As", `Saved as C:\\PICTURES\\${photo.name}.BAK`);
  const print = () =>
    msg("Print", `Sending ${photo.name} to HP DeskJet 550C...\n\n(No printer detected. This is a demo.)`);
  const copyMsg = () => msg("ACDSee", "Image copied to the clipboard.");
  const batch = () =>
    msg("Batch Convert", "Converting 12 files to GIF (128 colors)...\n\n12 done.  0 errors.");
  const search = () => msg("Find", "Searching C:\\PICTURES for *.JPG...\n\n12 file(s) found.");
  const help = () =>
    msg(
      "ACDSee Help",
      "Welcome to ACDSee!\n\nBrowse the demo folder with the arrow keys, zoom with + / -, tweak with T, and start a slideshow with P."
    );
  const exitAsk = () =>
    setDlg({
      k: "msg",
      title: "Confirm Exit",
      text: "Quit ACDSee now?",
      icon: "warn",
      buttons: [
        {
          label: "OK",
          act: () => {
            setDlg(null);
            setShutdown(true);
          },
        },
        { label: "Cancel", act: () => setDlg(null) },
      ],
    });

  const onStartItem = (id: StartItem) => {
    if (id === "programs")
      msg("Programs", "ACDSee 32 is already running.\n\nPaint and Windows Explorer are not installed in this demo.");
    else if (id === "docs")
      msg(
        "Recent Documents",
        PHOTOS.slice(0, 3)
          .map((p) => `C:\\PICTURES\\${p.name}`)
          .join("\n")
      );
    else if (id === "settings") msg("Settings", "The Control Panel is unavailable in this demo.");
    else if (id === "find") msg("Find", "Find: Search for files and folders.\n\n(Type *.JPG to find all demo pictures.)");
    else if (id === "help") msg("Help", "Microsoft Support is unavailable.\n\nTry ACDSee: Help, Help Contents.");
    else if (id === "run") setDlg({ k: "run" });
    else if (id === "shutdown")
      setDlg({
        k: "msg",
        title: "Shut Down Windows?",
        text: "Are you sure you want to turn off your computer?",
        icon: "warn",
        buttons: [
          {
            label: "Yes",
            act: () => {
              setDlg(null);
              setShutdown(true);
            },
          },
          { label: "No", act: () => setDlg(null) },
        ],
      });
  };

  /* keyboard shortcuts */
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement | null;
      if (t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.isContentEditable)) return;

      if (e.ctrlKey && !e.altKey && !e.metaKey) {
        const k = e.key.toLowerCase();
        if (k === "o") {
          e.preventDefault();
          open();
        } else if (k === "s") {
          e.preventDefault();
          if (e.shiftKey) saveAs();
          else save();
        } else if (k === "p") {
          e.preventDefault();
          print();
        } else if (k === "c") {
          e.preventDefault();
          copyMsg();
        } else if (k === "=") {
          e.preventDefault();
          zIn();
        } else if (k === "-") {
          e.preventDefault();
          zOut();
        }
        return;
      }

      if (e.key === "ArrowRight" || e.key === "PageDown") {
        e.preventDefault();
        nav(1);
      } else if (e.key === "ArrowLeft" || e.key === "PageUp") {
        e.preventDefault();
        nav(-1);
      } else if (e.key === "p" || e.key === "P") {
        setFw(false);
        setPlay((p) => !p);
      } else if (e.key === "f" || e.key === "F") {
        setFw((v) => !v);
      } else if (e.key === "0" || e.key === "F5") {
        setZoom({ m: "fit" });
      } else if (e.key === "1") {
        setZoom({ m: "pct", p: 100 });
      } else if (e.key === "+" || e.key === "=") {
        zIn();
      } else if (e.key === "-" || e.key === "_") {
        zOut();
      } else if (e.key === "t" || e.key === "T") {
        setDlg({ k: "tweak" });
      } else if (e.key === "Escape") {
        if (fw) setFw(false);
        else if (play) setPlay(false);
      }
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  });

  /* menus */
  const menus: MenuDef[] = [
    {
      label: "File",
      items: [
        { label: "Open...", sc: "Ctrl+O", act: open },
        { label: "Save", sc: "Ctrl+S", act: save },
        { label: "Save As...", sc: "Ctrl+Shift+S", act: saveAs },
        { sep: true },
        { label: "Print...", sc: "Ctrl+P", act: print },
        { sep: true },
        { label: "Exit", sc: "Alt+F4", act: exitAsk },
      ],
    },
    {
      label: "Image",
      items: [
        { label: "Zoom In", sc: "Ctrl+=", act: zIn },
        { label: "Zoom Out", sc: "Ctrl+-", act: zOut },
        { label: "Fit to Window", sc: "F5", act: () => setZoom({ m: "fit" }) },
        { label: "Actual Size", sc: "1:1", act: () => setZoom({ m: "pct", p: 100 }) },
        { sep: true },
        { label: "Rotate Left", act: () => setRot((r) => (r + 270) % 360) },
        { label: "Rotate Right", act: () => setRot((r) => (r + 90) % 360) },
        { label: "Flip Horizontal", act: () => setFH((v) => !v) },
        { label: "Flip Vertical", act: () => setFV((v) => !v) },
        { sep: true },
        { label: "Resize...", act: () => setDlg({ k: "resize" }) },
        { label: "Tweak...", sc: "T", act: () => setDlg({ k: "tweak" }) },
      ],
    },
    {
      label: "Edit",
      items: [
        { label: "Copy", sc: "Ctrl+C", act: copyMsg },
        { label: "Cut", sc: "Ctrl+X", dis: true },
        { label: "Paste", sc: "Ctrl+V", dis: true },
      ],
    },
    {
      label: "Slideshow",
      items: [
        { label: "Play", sc: "P", act: () => { setFw(false); setPlay(true); } },
        { label: "Stop", act: () => setPlay(false) },
        { sep: true },
        { label: "Options...", act: () => setDlg({ k: "options" }) },
      ],
    },
    {
      label: "Tools",
      items: [
        { label: "Tweak...", sc: "T", act: () => setDlg({ k: "tweak" }) },
        { label: "Batch Convert...", act: batch },
        { sep: true },
        { label: "Find...", act: search },
        { label: "Rename...", dis: true },
      ],
    },
    {
      label: "Window",
      items: [
        { label: "Thumbnails", chk: mode === "thumbnails", act: () => setMode("thumbnails") },
        { label: "Filmstrip", chk: mode === "filmstrip", act: () => setMode("filmstrip") },
        { label: "List", chk: mode === "list", act: () => setMode("list") },
        { label: "Split View", chk: mode === "split", act: () => setMode("split") },
      ],
    },
    {
      label: "Help",
      items: [
        { label: "Help Contents", sc: "F1", act: help },
        { sep: true },
        { label: "About ACDSee...", act: () => setDlg({ k: "about" }) },
      ],
    },
  ];

  const pick = (i: number) => {
    setPlay(false);
    setIdx(i);
  };
  const nextPhoto = PHOTOS[(idx + 1) % N];

  return (
    <div className="flex h-full flex-col">
      {/* ============ desktop ============ */}
      <div className="relative min-h-0 flex-1" onClick={() => setSelIcon(null)}>
        <div className="absolute left-2 top-2 z-0 flex flex-col gap-4">
          <DIcon
            label="My Computer"
            icon={<IcMyComputer size={32} />}
            sel={selIcon === "computer"}
            onClick={() => setSelIcon("computer")}
            onDbl={() =>
              msg("My Computer", "C:  (Hard disk, 850 MB)\n     348 MB free\n\nA:  (3.5 FD 1.44 MB)")
            }
          />
          <DIcon
            label="Recycle Bin"
            icon={<IcBin size={32} />}
            sel={selIcon === "bin"}
            onClick={() => setSelIcon("bin")}
            onDbl={() => msg("Recycle Bin", "The Recycle Bin is empty.")}
          />
          <DIcon
            label="ACDSee 32"
            icon={<IcLogo16 size={32} />}
            sel={selIcon === "acd"}
            onClick={() => setSelIcon("acd")}
            onDbl={() => setVis(true)}
          />
        </div>

        {/* ============ ACDSee window ============ */}
        {vis && (
          <div
            className="bevel-window absolute flex flex-col"
            style={
              maxi
                ? { inset: 0 }
                : {
                    left: "50%",
                    top: "50%",
                    transform: "translate(-50%, -50%)",
                    width: "min(880px, 94%)",
                    height: "min(560px, 88%)",
                  }
            }
          >
            <TitleBar
              title={`ACDSee - ${FOLDER}\\${photo.name}`}
              onMin={() => setVis(false)}
              onMax={() => setMaxi((v) => !v)}
              onClose={exitAsk}
            />
            <MenuBar menus={menus} />

            <Toolbar>
              <TBtn icon={<IcOpen />} tip="Open (Ctrl+O)" onClick={open} />
              <TBtn icon={<IcSave />} tip="Save (Ctrl+S)" onClick={save} />
              <TBtn icon={<IcPrint />} tip="Print (Ctrl+P)" onClick={print} />
              <TSep />
              <TBtn icon={<IcZoomOut />} tip="Zoom Out" onClick={zOut} />
              <TBtn icon={<IcZoomIn />} tip="Zoom In" onClick={zIn} />
              <TBtn icon={<IcFit />} tip="Fit to Window (F5)" onClick={() => setZoom({ m: "fit" })} />
              <TBtn icon={<IcActual />} tip="Actual Size (1:1)" onClick={() => setZoom({ m: "pct", p: 100 })} />
              <TSep />
              <TBtn icon={<IcFull />} tip="Full Screen (F)" onClick={() => setFw((v) => !v)} on={fw} />
              <TSep />
              <TBtn
                icon={<IcPlay />}
                tip="Play Slideshow (P)"
                onClick={() => {
                  setFw(false);
                  setPlay(true);
                }}
                on={play}
              />
              <TBtn icon={<IcStop />} tip="Stop Slideshow" onClick={() => setPlay(false)} />
              <TSep />
              <TBtn icon={<IcTweak />} tip="Tweak (T)" onClick={() => setDlg({ k: "tweak" })} />
            </Toolbar>

            <Toolbar>
              <TBtn icon={<IcThumb />} tip="Thumbnails View" on={mode === "thumbnails"} onClick={() => setMode("thumbnails")} />
              <TBtn icon={<IcFilm />} tip="Filmstrip View" on={mode === "filmstrip"} onClick={() => setMode("filmstrip")} />
              <TBtn icon={<IcList />} tip="List View" on={mode === "list"} onClick={() => setMode("list")} />
              <TBtn icon={<IcSplit />} tip="Split View" on={mode === "split"} onClick={() => setMode("split")} />
              <TSep />
              <TBtn icon={<IcCopy />} tip="Copy (Ctrl+C)" onClick={copyMsg} />
              <TSep />
              <TBtn icon={<IcRotL />} tip="Rotate Left" onClick={() => setRot((r) => (r + 270) % 360)} />
              <TBtn icon={<IcRotR />} tip="Rotate Right" onClick={() => setRot((r) => (r + 90) % 360)} />
              <TSep />
              <TBtn icon={<IcFlipH />} tip="Flip Horizontal" onClick={() => setFH((v) => !v)} />
              <TBtn icon={<IcFlipV />} tip="Flip Vertical" onClick={() => setFV((v) => !v)} />
            </Toolbar>

            {/* main content */}
            <div className="flex min-h-0 min-w-0 flex-1 gap-[3px] bg-[#c0c0c0] p-[3px]">
              <div
                className={
                  "min-h-0 min-w-0 flex-1 " +
                  (mode === "filmstrip" ? "flex flex-col gap-[3px]" : "flex")
                }
              >
                {mode === "split" ? (
                  <>
                    <Well
                      photo={photo}
                      nat={nat[photo.id]}
                      zoomScale={zoomScale}
                      rot={rot}
                      flipH={fH}
                      flipV={fV}
                      filter={filter}
                      onNat={onNat}
                      badge="A"
                    />
                    <div className="splitter" />
                    <Well
                      photo={nextPhoto}
                      nat={nat[nextPhoto.id]}
                      zoomScale={zoomScale}
                      rot={rot}
                      flipH={fH}
                      flipV={fV}
                      filter={filter}
                      onNat={onNat}
                      onPick={() => pick((idx + 1) % N)}
                      badge="B"
                    />
                  </>
                ) : (
                  <Well
                    photo={photo}
                    nat={nat[photo.id]}
                    zoomScale={zoomScale}
                    rot={rot}
                    flipH={fH}
                    flipV={fV}
                    filter={filter}
                    onNat={onNat}
                  />
                )}
                {mode === "filmstrip" && <Filmstrip photos={PHOTOS} idx={idx} onPick={pick} />}
              </div>
              {(mode === "thumbnails" || mode === "split") && (
                <SideThumbs photos={PHOTOS} idx={idx} onPick={pick} />
              )}
              {mode === "list" && <SideList photos={PHOTOS} idx={idx} onPick={pick} />}
            </div>

            <StatusBar
              cells={[
                [photo.name, 0],
                ["JPEG", 54],
                [`${nat[photo.id]?.w ?? photo.w} x ${nat[photo.id]?.h ?? photo.h}`, 88],
                [`${photo.kb} KB`, 62],
                [zoom.m === "fit" ? "Fit" : `${zoom.p}%`, 52],
                [`${idx + 1} of ${N}`, 60],
              ]}
            />
          </div>
        )}
      </div>

      {/* ============ taskbar ============ */}
      <Taskbar active={vis} onToggleTask={() => setVis((v) => !v)} onStartItem={onStartItem} />

      {/* ============ full screen ============ */}
      {fw && !play && (
        <div
          className="fixed inset-0 z-[64] flex overflow-hidden bg-[#4e4e4e]"
          onClick={() => setFw(false)}
        >
          <img
            src={photo.url}
            alt={photo.name}
            draggable={false}
            className="m-auto block max-h-full max-w-full shrink-0"
            style={{ transform: rotXform, filter }}
          />
          <div className="pointer-events-none absolute bottom-2 right-3 text-[11px] text-white/60">
            Full Screen - Esc or click to exit
          </div>
        </div>
      )}

      {/* ============ slideshow ============ */}
      {play && (
        <div
          className="fixed inset-0 z-[66] flex items-center justify-center bg-black"
          onClick={() => setPlay(false)}
        >
          <img
            src={photo.url}
            alt={photo.name}
            draggable={false}
            className="block max-h-full max-w-full"
            style={{ transform: rotXform, filter }}
          />
          <div className="pointer-events-none absolute bottom-2 right-3 text-[11px] text-white/50">
            {idx + 1} / {N} &nbsp;-&nbsp; Esc or click to stop
          </div>
        </div>
      )}

      {/* ============ dialogs ============ */}
      {dlg?.k === "about" && <AboutDlg onClose={() => setDlg(null)} />}
      {dlg?.k === "open" && (
        <OpenDlg
          photos={PHOTOS}
          onPick={(i) => {
            setDlg(null);
            pick(i);
          }}
          onClose={() => setDlg(null)}
        />
      )}
      {dlg?.k === "tweak" && (
        <TweakDlg
          st={filters}
          onChange={setFilters}
          onOk={() => setDlg(null)}
          onCancel={() => {
            setFilters({ b: 100, c: 100, s: 100, h: 0 });
            setDlg(null);
          }}
        />
      )}
      {dlg?.k === "resize" &&
        (() => {
          const n = nat[photo.id] ?? { w: photo.w, h: photo.h };
          const scale = zoom.m === "fit" ? 0.5 : zoomScale;
          return (
            <ResizeDlg
              cur={{ w: Math.round(n.w * scale), h: Math.round(n.h * scale) }}
              nat={n}
              onApply={(w) => {
                setZoom({ m: "pct", p: Math.max(1, Math.round((w / n.w) * 100)) });
                setDlg(null);
              }}
              onClose={() => setDlg(null)}
            />
          );
        })()}
      {dlg?.k === "options" && (
        <OptionsDlg
          dur={dur}
          loop={loop}
          onOk={(d, l) => {
            setDur(d);
            setLoop(l);
            setDlg(null);
          }}
          onClose={() => setDlg(null)}
        />
      )}
      {dlg?.k === "run" && (
        <RunDlg
          onRun={(s) => {
            setDlg(null);
            if (s.trim()) msg("Run", `Cannot find the file '${s}' in the specified path.`, "excl");
          }}
          onClose={() => setDlg(null)}
        />
      )}
      {dlg?.k === "msg" && (
        <Message
          title={dlg.title}
          text={dlg.text}
          icon={dlg.icon ?? "info"}
          buttons={dlg.buttons ?? [{ label: "OK", act: () => setDlg(null) }]}
        />
      )}

      {/* ============ shutdown ============ */}
      {shutdown && (
        <div
          className="fixed inset-0 z-[90] flex flex-col items-center justify-center bg-[#a4acbd]"
          onClick={() => setShutdown(false)}
        >
          <div className="px-4 text-center text-[20px] font-bold text-[#14181d]">
            It is now safe to turn off your computer.
          </div>
          <div className="mt-12 text-[11px] text-[#525b6b]">(click anywhere to power the demo back on)</div>
        </div>
      )}
    </div>
  );
}
