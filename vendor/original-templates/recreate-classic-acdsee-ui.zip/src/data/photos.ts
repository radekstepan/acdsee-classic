export interface Photo {
  id: string;
  name: string;
  w: number; // nominal (as listed in file dialogs)
  h: number;
  kb: number;
  date: string;
  url: string;
}

export const FOLDER = "C:\\PICTURES";

const px = (id: number, w: number) =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&w=${w}`;

const mk = (
  id: number,
  name: string,
  w: number,
  h: number,
  kb: number,
  date: string
): Photo => ({ id: String(id), name, w, h, kb, date, url: px(id, 1600) });

export const PHOTOS: Photo[] = [
  mk(40505942, "CANYON.JPG", 1024, 768, 286, "07/14/1998"),
  mk(33645145, "BEACH98.JPG", 800, 600, 152, "08/02/1998"),
  mk(20208915, "CITYNY.JPG", 1024, 768, 233, "06/21/1998"),
  mk(39894227, "ALPS.JPG", 800, 600, 178, "01/17/1998"),
  mk(5046379, "FALLS.JPG", 640, 480, 96, "05/30/1998"),
  mk(16592505, "PENGUIN.JPG", 1024, 768, 264, "11/09/1998"),
  mk(37871412, "MUSTANG.JPG", 800, 600, 141, "03/22/1998"),
  mk(11086515, "LIFTOFF.JPG", 640, 480, 88, "04/15/1998"),
  mk(28854501, "FERRIS.JPG", 1024, 768, 245, "09/27/1998"),
  mk(17951725, "HARBOR.JPG", 800, 600, 167, "06/08/1998"),
  mk(29685456, "ORCHID.JPG", 640, 480, 104, "02/14/1998"),
  mk(30810890, "REXY.JPG", 800, 600, 158, "12/25/1998"),
];

export const thumbUrl = (p: Photo) =>
  `https://images.pexels.com/photos/${p.id}/pexels-photo-${p.id}.jpeg?auto=compress&cs=tinysrgb&w=360`;
