type SP = { size?: number };
const C = { shapeRendering: "crispEdges" as const };

/* ============ toolbar icons (24 grid) ============ */

export const IcOpen = ({ size = 22 }: SP) => (
  <svg width={size} height={size} viewBox="0 0 24 24" {...C}>
    <rect x="6" y="3" width="12" height="7" fill="#fff" stroke="#808080" />
    <path d="M2 5 h8 l2 2 h10 v12 H2 Z" fill="#e8b04e" stroke="#6e4e12" />
    <path d="M1 20 L4 11 H23 L20 20 Z" fill="#ffd878" stroke="#6e4e12" />
  </svg>
);

export const IcSave = ({ size = 22 }: SP) => (
  <svg width={size} height={size} viewBox="0 0 24 24" {...C}>
    <rect x="3" y="3" width="18" height="18" fill="#2b4fa8" stroke="#101f4d" />
    <rect x="7" y="3" width="10" height="7" fill="#c8c8c8" stroke="#101f4d" />
    <rect x="13" y="4" width="3" height="5" fill="#20242c" />
    <rect x="6" y="13" width="12" height="8" fill="#fff" stroke="#101f4d" />
    <rect x="8" y="15" width="8" height="1" fill="#7d97cf" />
    <rect x="8" y="17" width="8" height="1" fill="#7d97cf" />
    <rect x="8" y="19" width="5" height="1" fill="#7d97cf" />
  </svg>
);

export const IcPrint = ({ size = 22 }: SP) => (
  <svg width={size} height={size} viewBox="0 0 24 24" {...C}>
    <rect x="6" y="2" width="12" height="8" fill="#fff" stroke="#555" />
    <rect x="3" y="10" width="18" height="8" fill="#b9b9b9" stroke="#3a3a3a" />
    <rect x="17" y="12" width="2" height="2" fill="#3fae3f" />
    <rect x="7" y="16" width="10" height="6" fill="#fff" stroke="#555" />
    <rect x="9" y="18" width="6" height="1" fill="#999" />
    <rect x="9" y="20" width="4" height="1" fill="#999" />
  </svg>
);

export const IcCopy = ({ size = 22 }: SP) => (
  <svg width={size} height={size} viewBox="0 0 24 24" {...C}>
    <rect x="3" y="2" width="12" height="14" fill="#fff" stroke="#666" />
    <rect x="5" y="5" width="8" height="1" fill="#8fb0e0" />
    <rect x="5" y="7" width="8" height="1" fill="#8fb0e0" />
    <rect x="5" y="9" width="6" height="1" fill="#8fb0e0" />
    <rect x="8" y="8" width="12" height="14" fill="#fff" stroke="#333" />
    <rect x="10" y="11" width="8" height="1" fill="#8fb0e0" />
    <rect x="10" y="13" width="8" height="1" fill="#8fb0e0" />
  </svg>
);

const Lens = ({ minus }: { minus?: boolean }) => (
  <>
    <circle cx="10" cy="10" r="6.5" fill="#d8ecff" stroke="#1c4e9e" strokeWidth="2" />
    {minus ? (
      <rect x="7" y="9" width="6" height="2" fill="#c02020" />
    ) : (
      <>
        <rect x="7" y="9" width="6" height="2" fill="#c02020" />
        <rect x="9" y="7" width="2" height="6" fill="#c02020" />
      </>
    )}
    <path d="M15 15 L21 21 L18 24 L12 18 Z" fill="#444" />
  </>
);

export const IcZoomIn = ({ size = 22 }: SP) => (
  <svg width={size} height={size} viewBox="0 0 24 24" {...C}>
    <Lens />
  </svg>
);
export const IcZoomOut = ({ size = 22 }: SP) => (
  <svg width={size} height={size} viewBox="0 0 24 24" {...C}>
    <Lens minus />
  </svg>
);

const Photo = ({ x, y, w, h }: { x: number; y: number; w: number; h: number }) => (
  <>
    <rect x={x} y={y} width={w} height={h} fill="#aee0ff" />
    <path
      d={`M${x} ${y + h} L${x + w * 0.35} ${y + h * 0.35} L${x + w * 0.6} ${y + h * 0.8} L${x + w * 0.75} ${y + h * 0.55} L${x + w} ${y + h * 0.95} L${x + w} ${y + h} Z`}
      fill="#2e8b2e"
    />
  </>
);

export const IcFit = ({ size = 22 }: SP) => (
  <svg width={size} height={size} viewBox="0 0 24 24" {...C}>
    <rect x="2" y="3" width="20" height="18" fill="#fff" stroke="#222" />
    <Photo x={5} y={6} w={14} h={10} />
    <path d="M2 8 V3 H7" fill="none" stroke="#1c4e9e" strokeWidth="2" />
    <path d="M17 3 H22 V8" fill="none" stroke="#1c4e9e" strokeWidth="2" />
    <path d="M22 16 V21 H17" fill="none" stroke="#1c4e9e" strokeWidth="2" />
    <path d="M7 21 H2 V16" fill="none" stroke="#1c4e9e" strokeWidth="2" />
  </svg>
);

export const IcActual = ({ size = 22 }: SP) => (
  <svg width={size} height={size} viewBox="0 0 24 24" {...C}>
    <rect x="2" y="3" width="20" height="18" fill="#fff" stroke="#222" />
    <Photo x={4} y={5} w={16} h={14} />
    <text
      x="12"
      y="15"
      textAnchor="middle"
      fontSize="8.5"
      fontWeight="bold"
      fontFamily="Tahoma, sans-serif"
      fill="#000"
      stroke="#fff"
      strokeWidth="2.5"
      paintOrder="stroke"
    >
      1:1
    </text>
  </svg>
);

export const IcFull = ({ size = 22 }: SP) => (
  <svg width={size} height={size} viewBox="0 0 24 24" {...C}>
    <rect x="2" y="2" width="20" height="20" fill="#aee0ff" stroke="#222" />
    <path d="M2 17 L8 11 L12 15 L15 12 L22 17 V22 H2 Z" fill="#2e8b2e" />
    <path d="M5 8 V5 H8" fill="none" stroke="#1c4e9e" strokeWidth="2" />
    <path d="M16 5 H19 V8" fill="none" stroke="#1c4e9e" strokeWidth="2" />
    <path d="M19 16 V19 H16" fill="none" stroke="#1c4e9e" strokeWidth="2" />
    <path d="M8 19 H5 V16" fill="none" stroke="#1c4e9e" strokeWidth="2" />
  </svg>
);

export const IcPlay = ({ size = 22 }: SP) => (
  <svg width={size} height={size} viewBox="0 0 24 24" {...C}>
    <path d="M7 3 L20 12 L7 21 Z" fill="#1c4e9e" stroke="#0a1e5e" />
  </svg>
);

export const IcStop = ({ size = 22 }: SP) => (
  <svg width={size} height={size} viewBox="0 0 24 24" {...C}>
    <rect x="5" y="5" width="14" height="14" fill="#1c4e9e" stroke="#0a1e5e" />
  </svg>
);

const MiniPhoto = ({ x, y }: { x: number; y: number }) => (
  <>
    <rect x={x} y={y} width={8} height={8} fill="#fff" stroke="#1c4e9e" />
    <rect x={x + 1} y={y + 1} width={6} height={3.5} fill="#aee0ff" />
    <path d={`M${x + 1} ${y + 7} L${x + 3.5} ${y + 4} L${x + 5.5} ${y + 7} Z`} fill="#2e8b2e" />
  </>
);

export const IcThumb = ({ size = 22 }: SP) => (
  <svg width={size} height={size} viewBox="0 0 24 24" {...C}>
    <MiniPhoto x={2} y={2} />
    <MiniPhoto x={14} y={2} />
    <MiniPhoto x={2} y={14} />
    <MiniPhoto x={14} y={14} />
  </svg>
);

export const IcFilm = ({ size = 22 }: SP) => (
  <svg width={size} height={size} viewBox="0 0 24 24" {...C}>
    <rect x="1" y="6" width="22" height="12" fill="#1a1a1a" />
    <rect x="3" y="7.5" width="2" height="3" fill="#fff" />
    <rect x="8" y="7.5" width="2" height="3" fill="#fff" />
    <rect x="13" y="7.5" width="2" height="3" fill="#fff" />
    <rect x="18" y="7.5" width="2" height="3" fill="#fff" />
    <rect x="3" y="13.5" width="2" height="3" fill="#fff" />
    <rect x="8" y="13.5" width="2" height="3" fill="#fff" />
    <rect x="13" y="13.5" width="2" height="3" fill="#fff" />
    <rect x="18" y="13.5" width="2" height="3" fill="#fff" />
    <rect x="2" y="11" width="20" height="3" fill="#e8b04e" />
  </svg>
);

export const IcList = ({ size = 22 }: SP) => (
  <svg width={size} height={size} viewBox="0 0 24 24" {...C}>
    <rect x="2" y="4" width="4" height="4" fill="#1c4e9e" />
    <rect x="9" y="5" width="13" height="2" fill="#444" />
    <rect x="2" y="10" width="4" height="4" fill="#1c4e9e" />
    <rect x="9" y="11" width="13" height="2" fill="#444" />
    <rect x="2" y="16" width="4" height="4" fill="#1c4e9e" />
    <rect x="9" y="17" width="13" height="2" fill="#444" />
  </svg>
);

export const IcSplit = ({ size = 22 }: SP) => (
  <svg width={size} height={size} viewBox="0 0 24 24" {...C}>
    <rect x="2" y="4" width="20" height="16" fill="#fff" stroke="#222" />
    <rect x="3" y="5" width="8" height="14" fill="#aee0ff" />
    <path d="M3 19 L7 13 L10 19 Z" fill="#2e8b2e" />
    <rect x="13" y="5" width="8" height="14" fill="#cdeecd" />
    <path d="M13 19 L16.5 11 L21 19 Z" fill="#2e8b2e" />
    <rect x="11" y="4" width="2" height="16" fill="#222" />
  </svg>
);

export const IcRotL = ({ size = 22 }: SP) => (
  <svg width={size} height={size} viewBox="0 0 24 24" {...C}>
    <path d="M12 4 A8 8 0 1 0 20 12" fill="none" stroke="#1c4e9e" strokeWidth="3" />
    <path d="M13 1 L6 4 L13 7 Z" fill="#1c4e9e" />
  </svg>
);

export const IcRotR = ({ size = 22 }: SP) => (
  <svg width={size} height={size} viewBox="0 0 24 24" {...C}>
    <path d="M12 4 A8 8 0 1 1 4 12" fill="none" stroke="#1c4e9e" strokeWidth="3" />
    <path d="M11 1 L18 4 L11 7 Z" fill="#1c4e9e" />
  </svg>
);

const FlipBase = ({ flip }: { flip: "h" | "v" }) => (
  <>
    <path d={flip === "h" ? "M3 6 H10 V18 H3 Z" : "M6 3 V10 H18 V3 Z"} fill="#1c4e9e" />
    <path d={flip === "h" ? "M21 6 H14 V18 H21 Z" : "M6 21 V14 H18 V21 Z"} fill="#7db0e8" />
    <rect x={flip === "h" ? 11 : 3} y={flip === "h" ? 6 : 11} width={flip === "h" ? 2 : 18} height={flip === "h" ? 12 : 2} fill="#fff" />
  </>
);

export const IcFlipH = ({ size = 22 }: SP) => (
  <svg width={size} height={size} viewBox="0 0 24 24" {...C}>
    <FlipBase flip="h" />
  </svg>
);

export const IcFlipV = ({ size = 22 }: SP) => (
  <svg width={size} height={size} viewBox="0 0 24 24" {...C}>
    <FlipBase flip="v" />
  </svg>
);

export const IcTweak = ({ size = 22 }: SP) => (
  <svg width={size} height={size} viewBox="0 0 24 24" {...C}>
    <path d="M14 2 L22 10 L9 23 L1 15 Z" fill="#7b3fb5" stroke="#3c1a63" />
    <path d="M18 16 H22 M20 14 V20" stroke="#f5b400" strokeWidth="2" />
    <path d="M12 18 H16 M14 16 V22" stroke="#f5b400" strokeWidth="2" />
    <path d="M20 4 H24 M22 2 V8" stroke="#f5b400" strokeWidth="2" />
  </svg>
);

/* ============ small chrome icons ============ */

export const IcMin = () => (
  <svg width="10" height="10" viewBox="0 0 10 10" {...C}>
    <rect x="1" y="8" width="7" height="2" fill="#000" />
  </svg>
);

export const IcMax = () => (
  <svg width="10" height="10" viewBox="0 0 10 10" {...C}>
    <rect x="1" y="1" width="8" height="8" fill="none" stroke="#000" strokeWidth="1" />
    <rect x="1" y="1" width="8" height="2" fill="#000" />
  </svg>
);

export const IcClose = () => (
  <svg width="10" height="10" viewBox="0 0 10 10">
    <path d="M1.5 1.5 L8.5 8.5 M8.5 1.5 L1.5 8.5" stroke="#000" strokeWidth="1.6" />
  </svg>
);

export const IcLogo16 = ({ size = 16 }: SP) => (
  <svg width={size} height={size} viewBox="0 0 16 16" {...C}>
    <rect x="0" y="0" width="16" height="16" fill="#fff" stroke="#555" />
    <rect x="1" y="2" width="14" height="9" fill="#8fd2ff" />
    <circle cx="12" cy="5" r="2" fill="#ff8f2a" stroke="#c25a08" />
    <path d="M1 11 L5 6 L8 11 L10 9 L13 11 V11 H1 Z" fill="#2e8b2e" />
    <rect x="1" y="11" width="14" height="3" fill="#2e7a2e" />
    <path d="M4 14 L6 12 L8 14 Z" fill="#1d5a1d" />
  </svg>
);

export const IcStart = ({ size = 16 }: SP) => (
  <svg width={size} height={size} viewBox="0 0 16 16" {...C}>
    <g transform="rotate(-8 8 8)">
      <rect x="2" y="3" width="6" height="6" fill="#2faa2f" />
      <rect x="8" y="2" width="6" height="6" fill="#d93a2a" />
      <rect x="2" y="9" width="6" height="6" fill="#2a55c9" />
      <rect x="8" y="8" width="6" height="6" fill="#f0c419" />
    </g>
  </svg>
);

export const IcFile16 = ({ size = 16 }: SP) => (
  <svg width={size} height={size} viewBox="0 0 16 16" {...C}>
    <path d="M3 1 H10 L14 5 V15 H3 Z" fill="#fff" stroke="#444" />
    <path d="M10 1 L10 5 L14 5 Z" fill="#d8d8d8" stroke="#444" />
    <rect x="5" y="7" width="7" height="6" fill="#aee0ff" stroke="#222" />
    <path d="M5 13 L8 9 L10 11 L12 13 Z" fill="#2e8b2e" />
  </svg>
);

export const IcInfo16 = ({ size = 16 }: SP) => (
  <svg width={size} height={size} viewBox="0 0 16 16" {...C}>
    <circle cx="8" cy="8" r="7" fill="#1c4e9e" stroke="#0a1e5e" />
    <rect x="7" y="4" width="2" height="2" fill="#fff" />
    <rect x="7" y="7" width="2" height="6" fill="#fff" />
  </svg>
);

export const IcWarn16 = ({ size = 16 }: SP) => (
  <svg width={size} height={size} viewBox="0 0 16 16" {...C}>
    <path d="M8 1 L15 14 H1 Z" fill="#ffd23e" stroke="#8a6a00" />
    <rect x="7" y="6" width="2" height="5" fill="#000" />
    <rect x="7" y="12" width="2" height="1.5" fill="#000" />
  </svg>
);

export const IcExcl16 = ({ size = 16 }: SP) => (
  <svg width={size} height={size} viewBox="0 0 16 16" {...C}>
    <circle cx="8" cy="8" r="7" fill="#c02020" stroke="#701010" />
    <rect x="7" y="3" width="2" height="7" fill="#fff" />
    <rect x="7" y="11" width="2" height="2" fill="#fff" />
  </svg>
);

export const IcCog = ({ size = 18 }: SP) => (
  <svg width={size} height={size} viewBox="0 0 24 24" {...C}>
    <rect x="10" y="1" width="4" height="6" fill="#808080" />
    <rect x="10" y="17" width="4" height="6" fill="#808080" />
    <rect x="1" y="10" width="6" height="4" fill="#808080" />
    <rect x="17" y="10" width="6" height="4" fill="#808080" />
    <rect x="4" y="4" width="4" height="4" fill="#808080" />
    <rect x="16" y="16" width="4" height="4" fill="#808080" />
    <rect x="4" y="16" width="4" height="4" fill="#808080" />
    <rect x="16" y="4" width="4" height="4" fill="#808080" />
    <rect x="7" y="7" width="10" height="10" fill="#a0a0a0" stroke="#555" />
    <circle cx="12" cy="12" r="3" fill="#e0e0e0" stroke="#555" />
  </svg>
);

export const IcPower = ({ size = 18 }: SP) => (
  <svg width={size} height={size} viewBox="0 0 24 24" {...C}>
    <path d="M12 4 A9 9 0 1 0 12.01 4" fill="none" stroke="#c02020" strokeWidth="3" />
    <rect x="10.5" y="1" width="3" height="9" fill="#c02020" />
  </svg>
);

export const IcArrowR = ({ size = 18 }: SP) => (
  <svg width={size} height={size} viewBox="0 0 24 24" {...C}>
    <rect x="2" y="9" width="14" height="6" fill="#c02020" />
    <path d="M14 5 L22 12 L14 19 Z" fill="#c02020" />
  </svg>
);

export const IcHelp = ({ size = 18 }: SP) => (
  <svg width={size} height={size} viewBox="0 0 24 24">
    <text x="12" y="18" textAnchor="middle" fontSize="20" fontWeight="bold" fontFamily="Tahoma, sans-serif" fill="#1c4e9e">
      ?
    </text>
  </svg>
);

/* ============ desktop icons (32) ============ */

export const IcMyComputer = ({ size = 32 }: SP) => (
  <svg width={size} height={size} viewBox="0 0 32 32" {...C}>
    <rect x="1" y="5" width="20" height="14" fill="#c8c8c8" stroke="#333" />
    <rect x="3" y="7" width="16" height="10" fill="#7ec8f0" stroke="#333" />
    <path d="M3 17 L8 11 L12 15 L15 12 L19 17 Z" fill="#2e8b2e" />
    <rect x="8" y="19" width="6" height="2" fill="#999" stroke="#333" />
    <rect x="4" y="21" width="14" height="3" fill="#c8c8c8" stroke="#333" />
    <rect x="22" y="8" width="8" height="17" fill="#c8c8c8" stroke="#333" />
    <rect x="24" y="10" width="4" height="1.5" fill="#808080" />
    <rect x="24" y="12" width="4" height="1.5" fill="#808080" />
    <rect x="24" y="19" width="4" height="3" fill="#808080" />
    <circle cx="26" cy="24" r="1" fill="#3fae3f" />
  </svg>
);

export const IcBin = ({ size = 32 }: SP) => (
  <svg width={size} height={size} viewBox="0 0 32 32" {...C}>
    <path d="M10 3 L14 6 L11 9 L15 10 L13 13" fill="none" stroke="#999" strokeWidth="1.5" />
    <path d="M14 2 L20 5 L16 8 L21 10" fill="none" stroke="#999" strokeWidth="1.5" />
    <rect x="7" y="10" width="18" height="3" fill="#c8c8c8" stroke="#333" />
    <path d="M9 13 L23 13 L21 29 L11 29 Z" fill="#b9b9b9" stroke="#333" />
    <rect x="12" y="16" width="1.5" height="10" fill="#808080" />
    <rect x="15.5" y="16" width="1.5" height="10" fill="#808080" />
    <rect x="19" y="16" width="1.5" height="10" fill="#808080" />
  </svg>
);

/* ============ About box logo ============ */

export const BigLogo = ({ width = 210 }: { width?: number }) => (
  <svg width={width} height={(width * 48) / 210} viewBox="0 0 210 48" {...C}>
    <rect x="0" y="4" width="40" height="40" fill="#fff" stroke="#555" />
    <rect x="2" y="8" width="36" height="22" fill="#8fd2ff" />
    <circle cx="29" cy="15" r="5" fill="#ff8f2a" stroke="#c25a08" />
    <path d="M2 30 L12 16 L20 30 Z" fill="#2e8b2e" />
    <path d="M16 30 L25 21 L38 30 Z" fill="#1d6a1d" />
    <rect x="2" y="30" width="36" height="12" fill="#2e8b2e" />
    <text x="48" y="34" fontFamily="Tahoma, sans-serif" fontSize="30" fontWeight="bold" fontStyle="italic" fill="#003399">
      ACD
    </text>
    <text x="106" y="34" fontFamily="Tahoma, sans-serif" fontSize="30" fontWeight="bold" fontStyle="italic" fill="#cc2222">
      See
    </text>
    <text x="48" y="46" fontFamily="Tahoma, sans-serif" fontSize="9" fill="#555">
      The ACD Graphics Viewer
    </text>
  </svg>
);
