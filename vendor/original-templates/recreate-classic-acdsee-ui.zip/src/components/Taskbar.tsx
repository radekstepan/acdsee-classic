import { useEffect, useState } from "react";
import {
  IcArrowR,
  IcCog,
  IcHelp,
  IcList,
  IcLogo16,
  IcOpen,
  IcPower,
  IcStart,
  IcZoomOut,
} from "./icons";

export type StartItem =
  | "programs"
  | "docs"
  | "settings"
  | "find"
  | "help"
  | "run"
  | "shutdown";

const ITEMS: { id: StartItem; label: string; icon: React.ReactNode }[] = [
  { id: "programs", label: "Programs", icon: <IcOpen size={18} /> },
  { id: "docs", label: "Documents", icon: <IcList size={18} /> },
  { id: "settings", label: "Settings", icon: <IcCog /> },
  { id: "find", label: "Find", icon: <IcZoomOut size={18} /> },
  { id: "help", label: "Help", icon: <IcHelp /> },
  { id: "run", label: "Run...", icon: <IcArrowR /> },
];

export function Taskbar({
  active,
  onToggleTask,
  onStartItem,
}: {
  active: boolean;
  onToggleTask: () => void;
  onStartItem: (id: StartItem) => void;
}) {
  const [start, setStart] = useState(false);
  const [now, setNow] = useState(() => new Date());

  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 10000);
    return () => clearInterval(t);
  }, []);

  const time = now.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });

  return (
    <>
      {start && (
        <>
          <div className="fixed inset-0 z-[58]" onClick={() => setStart(false)} />
          <div className="bevel-up fixed bottom-[31px] left-0 z-[60] flex w-[206px] bg-[#c0c0c0] py-[2px]">
            <div
              className="startband flex w-[24px] shrink-0 items-end justify-center pb-2"
              style={{ background: "linear-gradient(0deg, #1084d0, #000080)" }}
            >
              <span className="text-[16px] font-bold tracking-wide text-white">
                <span className="italic text-[#c0d8ff]">Windows</span> 98
              </span>
            </div>
            <div className="flex min-w-0 flex-1 flex-col py-[1px]">
              {ITEMS.map((it) => (
                <button
                  key={it.id}
                  className="flex h-[30px] items-center gap-2 px-2 text-left text-[11px] hover:bg-[#000080] hover:text-white"
                  onClick={() => {
                    setStart(false);
                    onStartItem(it.id);
                  }}
                >
                  <span className="flex w-[20px] shrink-0 justify-center">{it.icon}</span>
                  {it.label}
                </button>
              ))}
              <div className="mx-2 my-[3px] h-0 border-t border-[#808080] shadow-[0_1px_0_#fff]" />
              <button
                className="flex h-[30px] items-center gap-2 px-2 text-left text-[11px] hover:bg-[#000080] hover:text-white"
                onClick={() => {
                  setStart(false);
                  onStartItem("shutdown");
                }}
              >
                <span className="flex w-[20px] shrink-0 justify-center">
                  <IcPower />
                </span>
                Shut Down...
              </button>
            </div>
          </div>
        </>
      )}

      <div
        className="relative z-[62] flex h-[30px] shrink-0 items-center gap-[3px] bg-[#c0c0c0] px-[3px]"
        style={{ borderTop: "1px solid #fff", boxShadow: "0 -1px 0 #dfdfdf" }}
      >
        <button
          className={"btn98 h-[24px] min-w-0 gap-[5px] px-[8px] font-bold " + (start ? "pressed" : "")}
          onClick={() => setStart((v) => !v)}
        >
          <IcStart size={15} />
          Start
        </button>
        <div className="sep-v" style={{ height: 24 }} />
        <button
          className={
            "btn98 h-[24px] min-w-0 flex-1 justify-start gap-[6px] px-[8px] " +
            (active ? "pressed" : "")
          }
          onClick={onToggleTask}
        >
          <IcLogo16 size={14} />
          <span className="truncate">ACDSee 32</span>
        </button>
        <div className="groove flex h-[24px] shrink-0 items-center px-[8px] text-[11px]">
          {time}
        </div>
      </div>
    </>
  );
}
