import { ReactNode, useState } from "react";
import { Photo } from "../data/photos";
import { BigLogo, IcClose, IcExcl16, IcFile16, IcInfo16, IcWarn16 } from "./icons";

/* ---------------- shell ---------------- */

export function Dialog({
  title,
  w,
  children,
  onClose,
}: {
  title: string;
  w: number;
  children: ReactNode;
  onClose: () => void;
}) {
  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center">
      <div className="absolute inset-0" />
      <div
        className="bevel-window relative p-[3px] shadow-[6px_6px_14px_rgba(0,0,0,0.45)]"
        style={{ width: w }}
      >
        <div
          className="flex h-[18px] items-center pl-1 pr-[2px]"
          style={{ background: "linear-gradient(90deg, #000080, #1084d0)" }}
        >
          <span className="flex-1 truncate px-1 text-[11px] font-bold text-white">{title}</span>
          <button className="t98btn" onClick={onClose}>
            <IcClose />
          </button>
        </div>
        <div className="p-[12px]">{children}</div>
      </div>
    </div>
  );
}

export function Btn98({
  children,
  onClick,
  def,
}: {
  children: ReactNode;
  onClick?: () => void;
  def?: boolean;
}) {
  return (
    <button className={"btn98" + (def ? " btn-def" : "")} onClick={onClick}>
      {children}
    </button>
  );
}

export function Cb98({
  checked,
  onChange,
  label,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  label: string;
}) {
  return (
    <div className="flex items-center gap-[5px] text-[11px]" onClick={() => onChange(!checked)}>
      <span className="cb98">
        {checked && (
          <svg width="9" height="9" viewBox="0 0 10 10">
            <path d="M1 5.5 L3.5 8 L9 1.5" fill="none" stroke="#000" strokeWidth="1.6" />
          </svg>
        )}
      </span>
      {label}
    </div>
  );
}

/* ---------------- message box ---------------- */

export interface MsgButtons {
  label: string;
  act: () => void;
}

export function Message({
  title,
  text,
  icon = "info",
  buttons,
}: {
  title: string;
  text: string;
  icon?: "info" | "warn" | "excl";
  buttons: MsgButtons[];
}) {
  return (
    <Dialog title={title} w={360} onClose={buttons[buttons.length - 1].act}>
      <div className="flex gap-3">
        <div className="shrink-0 pt-[2px]">
          {icon === "info" ? <IcInfo16 size={20} /> : icon === "warn" ? <IcWarn16 size={20} /> : <IcExcl16 size={20} />}
        </div>
        <div className="whitespace-pre-wrap pt-[4px] text-[11px] leading-[15px]">{text}</div>
      </div>
      <div className="mt-4 flex justify-center gap-[8px]">
        {buttons.map((b) => (
          <Btn98 key={b.label} def={buttons.length === 1} onClick={b.act}>
            {b.label}
          </Btn98>
        ))}
      </div>
    </Dialog>
  );
}

/* ---------------- about ---------------- */

export function AboutDlg({ onClose }: { onClose: () => void }) {
  return (
    <Dialog title="About ACDSee" w={390} onClose={onClose}>
      <div className="flex flex-col items-center gap-[10px]">
        <BigLogo width={212} />
        <div className="text-center text-[11px] leading-[15px]">
          ACDSee 32, Version 4.00
          <br />
          Copyright (c) 1994 - 2000 ACD Systems Ltd.
          <br />
          All rights reserved.
        </div>
        <div className="well2 w-full bg-white p-2 text-[11px] leading-[15px]">
          Licensed to: <b>Demo User</b>
          <br />
          Windows 98, Build 4.10.2222
          <br />
          64 MB RAM &nbsp;&bull;&nbsp; 1280 x 1024, 16 colors
        </div>
        <Btn98 def onClick={onClose}>
          OK
        </Btn98>
      </div>
    </Dialog>
  );
}

/* ---------------- open file ---------------- */

export function OpenDlg({
  photos,
  onPick,
  onClose,
}: {
  photos: Photo[];
  onPick: (i: number) => void;
  onClose: () => void;
}) {
  const [sel, setSel] = useState(0);
  return (
    <Dialog title="Open" w={430} onClose={onClose}>
      <div className="mb-[6px] flex items-center gap-2">
        <span className="text-[11px]">Look in:</span>
        <div className="tx98 flex h-[21px] flex-1 items-center px-1">{`C:\\PICTURES`}</div>
      </div>
      <div className="well2 w98sc h-[218px] overflow-y-auto bg-white p-[2px]">
        {photos.map((p, i) => (
          <div
            key={p.id}
            onClick={() => setSel(i)}
            onDoubleClick={() => onPick(i)}
            className={
              "flex h-[19px] items-center gap-2 px-1 " +
              (i === sel ? "bg-[#000080] text-white" : "")
            }
          >
            <IcFile16 size={14} />
            <span className="flex-1 truncate text-[11px]">{p.name}</span>
            <span className="w-[52px] shrink-0 text-right text-[11px]">{p.kb} KB</span>
          </div>
        ))}
      </div>
      <div className="mt-2 flex items-center gap-2">
        <span className="text-[11px]">File name:</span>
        <div className="tx98 flex h-[21px] flex-1 items-center px-1">{photos[sel]?.name}</div>
      </div>
      <div className="mt-2 flex items-center gap-2">
        <span className="text-[11px]">Files of type:</span>
        <div className="tx98 flex h-[21px] flex-1 items-center px-1">JPEG Files (*.JPG)</div>
      </div>
      <div className="mt-4 flex justify-end gap-[8px]">
        <Btn98 def onClick={() => onPick(sel)}>
          Open
        </Btn98>
        <Btn98 onClick={onClose}>Cancel</Btn98>
      </div>
    </Dialog>
  );
}

/* ---------------- tweak ---------------- */

export interface TweakState {
  b: number;
  c: number;
  s: number;
  h: number;
}

function TRow({
  label,
  val,
  min,
  max,
  onChange,
}: {
  label: string;
  val: number;
  min: number;
  max: number;
  onChange: (v: number) => void;
}) {
  return (
    <div className="flex items-center gap-2">
      <span className="w-[72px] shrink-0 text-[11px]">{label}</span>
      <input
        type="range"
        className="rg98 min-w-0 flex-1"
        min={min}
        max={max}
        value={val}
        onChange={(e) => onChange(Number(e.target.value))}
      />
      <span className="w-[36px] shrink-0 text-right text-[11px]">{val}</span>
    </div>
  );
}

export function TweakDlg({
  st,
  onChange,
  onOk,
  onCancel,
}: {
  st: TweakState;
  onChange: (st: TweakState) => void;
  onOk: () => void;
  onCancel: () => void;
}) {
  return (
    <Dialog title="Tweak" w={330} onClose={onCancel}>
      <div className="flex flex-col gap-[8px]">
        <TRow label="Brightness" val={st.b} min={40} max={160} onChange={(v) => onChange({ ...st, b: v })} />
        <TRow label="Contrast" val={st.c} min={40} max={160} onChange={(v) => onChange({ ...st, c: v })} />
        <TRow label="Saturation" val={st.s} min={0} max={200} onChange={(v) => onChange({ ...st, s: v })} />
        <TRow label="Hue" val={st.h} min={0} max={360} onChange={(v) => onChange({ ...st, h: v })} />
      </div>
      <div className="mt-4 flex justify-end gap-[8px]">
        <Btn98 onClick={() => onChange({ b: 100, c: 100, s: 100, h: 0 })}>Reset</Btn98>
        <Btn98 onClick={onCancel}>Cancel</Btn98>
        <Btn98 def onClick={onOk}>OK</Btn98>
      </div>
    </Dialog>
  );
}

/* ---------------- resize ---------------- */

export function ResizeDlg({
  cur,
  nat,
  onApply,
  onClose,
}: {
  cur: { w: number; h: number };
  nat: { w: number; h: number };
  onApply: (w: number) => void;
  onClose: () => void;
}) {
  const [w, setW] = useState(cur.w);
  const [h, setH] = useState(cur.h);
  const [lock, setLock] = useState(true);
  const setWc = (v: number) => {
    setW(v);
    if (lock && nat.w) setH(Math.round((v * nat.h) / nat.w));
  };
  const setHc = (v: number) => {
    setH(v);
    if (lock && nat.w) setW(Math.round((v * nat.w) / nat.h));
  };
  return (
    <Dialog title="Resize Image" w={310} onClose={onClose}>
      <div className="flex flex-col gap-2 text-[11px]">
        <div className="flex items-center gap-2">
          <span className="w-[60px]">Width:</span>
          <input
            type="number"
            className="tx98 h-[21px] w-[70px]"
            value={w}
            min={16}
            max={nat.w * 2}
            onChange={(e) => setWc(Number(e.target.value) || 0)}
          />
          <span>pixels</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-[60px]">Height:</span>
          <input
            type="number"
            className="tx98 h-[21px] w-[70px]"
            value={h}
            min={16}
            max={nat.h * 2}
            onChange={(e) => setHc(Number(e.target.value) || 0)}
          />
          <span>pixels</span>
        </div>
        <div className="pt-1">
          <Cb98 checked={lock} onChange={setLock} label="Maintain aspect ratio" />
        </div>
      </div>
      <div className="mt-4 flex justify-end gap-[8px]">
        <Btn98 onClick={onClose}>Cancel</Btn98>
        <Btn98 def onClick={() => onApply(w)}>Apply</Btn98>
      </div>
    </Dialog>
  );
}

/* ---------------- slideshow options ---------------- */

export function OptionsDlg({
  dur,
  loop,
  onOk,
  onClose,
}: {
  dur: number;
  loop: boolean;
  onOk: (dur: number, loop: boolean) => void;
  onClose: () => void;
}) {
  const [d, setD] = useState(dur);
  const [l, setL] = useState(loop);
  return (
    <Dialog title="Slideshow Options" w={320} onClose={onClose}>
      <div className="flex flex-col gap-3 text-[11px]">
        <div className="flex items-center gap-2">
          <span className="w-[100px]">Slide duration:</span>
          <input
            type="number"
            className="tx98 h-[21px] w-[52px]"
            min={1}
            max={30}
            value={d}
            onChange={(e) => setD(Math.max(1, Math.min(30, Number(e.target.value) || 1)))}
          />
          <span>seconds</span>
        </div>
        <Cb98 checked={l} onChange={setL} label="Loop (repeat when finished)" />
        <div className="mt-1 text-[11px] leading-[14px] text-[#444]">
          Tip: press P to start a slideshow, Esc to stop it.
        </div>
      </div>
      <div className="mt-4 flex justify-end gap-[8px]">
        <Btn98 onClick={onClose}>Cancel</Btn98>
        <Btn98 def onClick={() => onOk(d, l)}>OK</Btn98>
      </div>
    </Dialog>
  );
}

/* ---------------- run... ---------------- */

export function RunDlg({
  onRun,
  onClose,
}: {
  onRun: (s: string) => void;
  onClose: () => void;
}) {
  const [s, setS] = useState("");
  return (
    <Dialog title="Run" w={340} onClose={onClose}>
      <div className="text-[11px]">Type the name of a program, document, or folder, and Windows will open it for you.</div>
      <div className="mt-3 flex items-center gap-2">
        <span className="text-[11px]">Open:</span>
        <input
          autoFocus
          className="tx98 h-[21px] flex-1"
          value={s}
          onChange={(e) => setS(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") onRun(s);
          }}
        />
      </div>
      <div className="mt-4 flex justify-end gap-[8px]">
        <Btn98 def onClick={() => onRun(s)}>OK</Btn98>
        <Btn98 onClick={onClose}>Cancel</Btn98>
      </div>
    </Dialog>
  );
}
