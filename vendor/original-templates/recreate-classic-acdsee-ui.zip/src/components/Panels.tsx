import { CSSProperties, useEffect, useRef, useState } from "react";
import { Photo, FOLDER, thumbUrl } from "../data/photos";
import { IcFile16 } from "./icons";

/* ---------------- image well ---------------- */

export function Well({
  photo,
  nat,
  zoomScale,
  rot,
  flipH,
  flipV,
  filter,
  onNat,
  onPick,
  badge,
}: {
  photo?: Photo;
  nat?: { w: number; h: number };
  zoomScale: number;
  rot: number;
  flipH: boolean;
  flipV: boolean;
  filter: string;
  onNat?: (id: string, n: { w: number; h: number }) => void;
  onPick?: () => void;
  badge?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [box, setBox] = useState({ w: 0, h: 0 });

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const upd = () => setBox({ w: el.clientWidth, h: el.clientHeight });
    upd();
    const ro = new ResizeObserver(upd);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const transform = `rotate(${rot}deg)${flipH ? " scaleX(-1)" : ""}${flipV ? " scaleY(-1)" : ""}`;

  let sized: CSSProperties | undefined;
  if (photo && nat && box.w > 8) {
    const sf = Math.min((box.w - 8) / nat.w, (box.h - 8) / nat.h);
    const s = Math.max(0.001, sf * zoomScale);
    let w = nat.w * s;
    let h = nat.h * s;
    if (rot % 180) [w, h] = [h, w];
    sized = {
      width: Math.max(2, Math.floor(w)),
      height: Math.max(2, Math.floor(h)),
      boxShadow: "5px 5px 0 rgba(0,0,0,0.35)",
    };
  }

  return (
    <div
      ref={ref}
      className="well2 w98sc relative flex flex-1 overflow-auto bg-[#4e4e4e]"
      style={{ minWidth: 0, minHeight: 0 }}
    >
      {photo ? (
        sized ? (
          <div className="m-auto shrink-0" style={sized} onClick={onPick}>
            <img
              src={photo.url}
              alt={photo.name}
              draggable={false}
              className="block h-full w-full"
              style={{ transform, filter }}
              onLoad={(e) =>
                onNat?.(photo.id, {
                  w: e.currentTarget.naturalWidth,
                  h: e.currentTarget.naturalHeight,
                })
              }
            />
          </div>
        ) : (
          <img
            src={photo.url}
            alt={photo.name}
            draggable={false}
            className="m-auto block shrink-0"
            style={{ maxWidth: "100%", maxHeight: "100%", transform, filter }}
            onLoad={(e) =>
              onNat?.(photo.id, {
                w: e.currentTarget.naturalWidth,
                h: e.currentTarget.naturalHeight,
              })
            }
          />
        )
      ) : (
        <div className="m-auto text-[12px] text-[#9a9a9a]">No image open</div>
      )}
      {badge && (
        <div className="absolute right-2 top-2 z-10 bg-black/60 px-[6px] py-[1px] text-[11px] text-white">
          {badge}
        </div>
      )}
    </div>
  );
}

/* ---------------- thumbnail cell ---------------- */

export function ThumbCell({
  p,
  sel,
  onClick,
  mini,
}: {
  p: Photo;
  sel: boolean;
  onClick: () => void;
  mini?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className="flex shrink-0 flex-col items-center"
      style={{ width: mini ? 96 : "100%" }}
    >
      <div className={"thwell" + (sel ? " sel" : "")} style={{ height: mini ? 62 : 76 }}>
        <img
          src={thumbUrl(p)}
          alt={p.name}
          draggable={false}
          loading="lazy"
          className="max-h-full max-w-full object-contain"
        />
      </div>
      <div
        className={
          "w-full truncate text-center text-[10px] leading-[13px] " +
          (sel ? "bg-[#000080] text-white" : "")
        }
      >
        {p.name}
      </div>
    </button>
  );
}

/* ---------------- right-side thumbnail panel ---------------- */

export function SideThumbs({
  photos,
  idx,
  onPick,
}: {
  photos: Photo[];
  idx: number;
  onPick: (i: number) => void;
}) {
  return (
    <div className="flex w-[172px] shrink-0 flex-col" style={{ minWidth: 0 }}>
      <div className="flex h-[18px] shrink-0 items-center gap-[5px] border-b border-[#808080] bg-[#c0c0c0] px-1 text-[11px]">
        <IcFile16 size={12} />
        {FOLDER}
      </div>
      <div className="well2 w98sc min-h-0 flex-1 overflow-y-auto bg-[#c0c0c0] p-[4px]">
        {photos.map((p, i) => (
          <div key={p.id} className="pb-[5px]">
            <ThumbCell p={p} sel={i === idx} onClick={() => onPick(i)} />
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------------- filmstrip (bottom) ---------------- */

export function Filmstrip({
  photos,
  idx,
  onPick,
}: {
  photos: Photo[];
  idx: number;
  onPick: (i: number) => void;
}) {
  return (
    <div className="h-[92px] w-full shrink-0">
      <div className="well2 w98sc flex h-full items-start gap-[4px] overflow-x-auto overflow-y-hidden bg-[#c0c0c0] p-[4px]">
        {photos.map((p, i) => (
          <ThumbCell key={p.id} p={p} mini sel={i === idx} onClick={() => onPick(i)} />
        ))}
      </div>
    </div>
  );
}

/* ---------------- right-side list panel ---------------- */

export function SideList({
  photos,
  idx,
  onPick,
}: {
  photos: Photo[];
  idx: number;
  onPick: (i: number) => void;
}) {
  return (
    <div className="flex w-[196px] shrink-0 flex-col" style={{ minWidth: 0 }}>
      <div className="flex h-[18px] shrink-0 items-center gap-[5px] border-b border-[#808080] bg-[#c0c0c0] px-1 text-[11px]">
        <IcFile16 size={12} />
        {FOLDER}
      </div>
      <div className="well2 w98sc min-h-0 flex-1 overflow-y-auto bg-[#c0c0c0] p-[2px]">
        <div className="grid grid-cols-[1fr_36px_52px] gap-[2px]">
          {["NAME", "TYPE", "SIZE"].map((h) => (
            <div
              key={h}
              className="raise1 flex h-[18px] items-center bg-[#c0c0c0] px-[5px] font-bold"
            >
              {h}
            </div>
          ))}
        </div>
        {photos.map((p, i) => (
          <button
            key={p.id}
            onClick={() => onPick(i)}
            className={
              "grid h-[19px] grid-cols-[1fr_36px_52px] items-center text-left text-[11px] " +
              (i === idx ? "bg-[#000080] text-white" : "hover:bg-[#c9c9c9]")
            }
          >
            <span className="flex min-w-0 items-center gap-[4px] pr-1">
              <IcFile16 size={12} />
              <span className="truncate">{p.name}</span>
            </span>
            <span className="truncate">JPG</span>
            <span className="truncate pr-2 text-right">{p.kb} KB</span>
          </button>
        ))}
      </div>
    </div>
  );
}
