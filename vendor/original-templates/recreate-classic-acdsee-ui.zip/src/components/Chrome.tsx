import { ReactNode, useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { IcClose, IcLogo16, IcMax, IcMin } from "./icons";

/* ---------------- title bar ---------------- */

export function TitleBar({
  title,
  onMin,
  onMax,
  onClose,
}: {
  title: string;
  onMin: () => void;
  onMax: () => void;
  onClose: () => void;
}) {
  return (
    <div
      className="flex h-[22px] shrink-0 items-stretch pl-[3px] pr-[2px]"
      style={{ background: "linear-gradient(90deg, #000080, #1084d0)" }}
    >
      <IcLogo16 size={16} />
      <div className="flex min-w-0 flex-1 items-center px-2">
        <span className="truncate text-[11px] font-bold text-white">{title}</span>
      </div>
      <div className="flex items-center gap-[2px]">
        <button className="t98btn" onClick={onMin} aria-label="Minimize">
          <IcMin />
        </button>
        <button className="t98btn" onClick={onMax} aria-label="Maximize">
          <IcMax />
        </button>
        <button className="t98btn ml-[4px]" onClick={onClose} aria-label="Close">
          <IcClose />
        </button>
      </div>
    </div>
  );
}

/* ---------------- menu bar ---------------- */

export interface MItem {
  label?: string;
  sc?: string;
  sep?: boolean;
  dis?: boolean;
  chk?: boolean;
  act?: () => void;
}
export interface MenuDef {
  label: string;
  items: MItem[];
}

export function MenuBar({ menus }: { menus: MenuDef[] }) {
  const [open, setOpen] = useState<number | null>(null);

  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(null);
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, []);

  return (
    <div className="relative z-50 flex h-[20px] shrink-0 items-stretch bg-[#c0c0c0]">
      {open !== null && (
        <div className="fixed inset-0 z-40" onClick={() => setOpen(null)} />
      )}
      {menus.map((m, i) => (
        <span key={m.label} className="relative z-50">
          <button
            className={
              "h-full px-[6px] text-[11px] " +
              (open === i ? "bg-[#000080] text-white" : "hover:bg-[#000080] hover:text-white")
            }
            onClick={() => setOpen(open === i ? null : i)}
            onMouseEnter={() => {
              if (open !== null) setOpen(i);
            }}
          >
            <u>{m.label[0]}</u>
            {m.label.slice(1)}
          </button>
          {open === i && (
            <div className="bevel-up absolute left-0 top-full z-50 min-w-[185px] bg-white py-[2px]">
              {m.items.map((it, j) =>
                it.sep ? (
                  <div key={j} className="menusep mx-[2px]" />
                ) : (
                  <button
                    key={j}
                    disabled={it.dis}
                    className={"menuitem" + (it.dis ? " dis" : "")}
                    onClick={() => {
                      setOpen(null);
                      it.act?.();
                    }}
                  >
                    <span className="w-[18px] shrink-0 text-center">{it.chk ? "✓" : ""}</span>
                    <span>{it.label}</span>
                    <span className="ml-[28px] text-right">{it.sc}</span>
                  </button>
                )
              )}
            </div>
          )}
        </span>
      ))}
    </div>
  );
}

/* ---------------- toolbar ---------------- */

export function Toolbar({ children }: { children: ReactNode }) {
  return (
    <div className="flex shrink-0 items-center gap-[1px] border-b border-[#808080] bg-[#c0c0c0] px-[3px] py-[3px] shadow-[0_1px_0_#fff]">
      {children}
    </div>
  );
}

export function TBtn({
  icon,
  tip,
  onClick,
  on,
  dis,
}: {
  icon: ReactNode;
  tip: string;
  onClick: () => void;
  on?: boolean;
  dis?: boolean;
}) {
  const [pos, setPos] = useState<{ x: number; y: number } | null>(null);
  const timer = useRef<number>(0);
  return (
    <>
      <button
        className={"tbtn" + (on ? " on" : "")}
        disabled={dis}
        onClick={() => {
          setPos(null);
          onClick();
        }}
        onMouseEnter={(e) => {
          window.clearTimeout(timer.current);
          timer.current = window.setTimeout(() => {
            const r = e.currentTarget.getBoundingClientRect();
            setPos({ x: r.left + 2, y: r.bottom + 3 });
          }, 550);
        }}
        onMouseLeave={() => {
          window.clearTimeout(timer.current);
          setPos(null);
        }}
      >
        {icon}
      </button>
      {pos &&
        createPortal(
          <div className="tip98" style={{ left: pos.x, top: pos.y }}>
            {tip}
          </div>,
          document.body
        )}
    </>
  );
}

export const TSep = () => <div className="sep-v" />;

/* ---------------- status bar ---------------- */

export function StatusBar({ cells }: { cells: [string, number][] }) {
  return (
    <div className="flex h-[20px] shrink-0 items-stretch gap-[2px] bg-[#c0c0c0] px-[2px] pb-[2px]">
      {cells.map(([txt, w], i) => (
        <div
          key={i}
          className={
            "groove flex min-w-0 items-center px-[5px] text-[11px] " +
            (w ? "shrink-0" : "flex-1")
          }
          style={w ? { width: w } : undefined}
        >
          <span className="truncate">{txt}</span>
        </div>
      ))}
    </div>
  );
}
